'use strict';
(() => {

    const eventDate = document.querySelector('h1');
    const weatherState = document.querySelector('h2');
    const nextHoliday = document.querySelector('h3');
    const userCity = document.querySelector('#cityInput');
    const dataButton = document.querySelector('button');
    const currentDate = document.querySelector('#currDate');
    currentDate.innerHTML = "Current Date: " +new Date(); 
    

    const handleWeather = (data) => {
        eventDate.innerHTML = data.location.name;
        weatherState.innerHTML = data.current.weather_descriptions[0];

        console.log("Weather:", data.location.name);
    };

    const handleHoliday = (data) => {
      let results = "";

    for (let i = 0; i < data.length; i++) {
        results += data[i].localName + " on " + data[i].date + "<br>";
    }

    nextHoliday.innerHTML = results;

    console.log("All Holidays:", data);
    };

    const fetchHoliday = () => {
        const holidayUrl = 'https://date.nager.at/api/v3/PublicHolidays/2026/US';

        fetch(holidayUrl)
            .then(response => response.json())
            .then(json => handleHoliday(json))
            .catch(error => {
                console.error('Error fetching holiday data:', error);
            });
    };

    const fetchWeather = () => {
        const weatherUrl = `https://api.weatherstack.com/current?access_key=d7f2d7fa8a9b4d97875cc89a6e048466&query=${userCity.value}`;

        fetch(weatherUrl)
            .then(response => response.json())
            .then(json => handleWeather(json))
            .catch(error => {
                console.error('Error fetching weather data:', error);
            });
    };

    dataButton.addEventListener('click', () => {
        fetchWeather();
        fetchHoliday();
        const holidayHeader = document.querySelector('#holidayHeader');
        holidayHeader.innerHTML = "Upcoming Holidays in the US for 2026";
    });

})();
