'use strict';

(() => {
    const currentRegion = document.querySelector("section");
    const soundButtons = Array.from(currentRegion.querySelectorAll("button"));

    currentRegion.addEventListener("click", (event) => {
    const button = event.target.closest("button");
    if (!button) return;

    const key = button.id;

    if (key === "w") {
        const audio = document.querySelector("#mouse");
        audio.currentTime = 0;
        audio.play();
    }

    if (key === "a") {
        const audio = document.querySelector("#pop");
        audio.currentTime = 0;
        audio.play();
    }

    if (key === "s") {
        const audio = document.querySelector("#ding");
        audio.currentTime = 0;
        audio.play();
    }

    if (key === "d") {
        const audio = document.querySelector("#boom");
        audio.currentTime = 0;
        audio.play();
    }
});
    document.addEventListener("keydown", (event) => {

        const key = event.key.toLowerCase();
        const button = document.querySelector("#" + key);

        if (button) button.click();

        if (key === "enter" && document.activeElement) {
            document.activeElement.click();
        }

        if (key === "w") {
            document.querySelector("#mouse")?.play();
        }

        if (key === "a") {
            document.querySelector("#pop")?.play();
        }

        if (key === "s") {
            document.querySelector("#ding")?.play();
        }
        
        if (key === "d") {
            document.querySelector("#boom")?.play();
        }
        if (key === "arrowdown") {
            moveFocus(1);
        }
        if (key === "arrowup") {
            moveFocus(-1);
        }
    });
         


function moveFocus(direction) {
        const currentIndex = soundButtons.indexOf(document.activeElement);
        let nextIndex = currentIndex + direction;

        if (nextIndex < 0) nextIndex = soundButtons.length - 1;
        if (nextIndex >= soundButtons.length) nextIndex = 0;

        soundButtons[nextIndex].focus();
    }
})();