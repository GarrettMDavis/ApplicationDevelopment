"use strict";

(() => {

    class Employee {
        constructor(name, id, age, payRate, hoursPerWeek) {
            this.name = name;
            this.id = id;
            this.age = age;
            this.payRate = payRate;
            this.hoursPerWeek = hoursPerWeek;
        }
    }

    let employees = [];

    const addEmployee = () => {
        let input = prompt(
            "Enter employee info separated by commas:\n" +
            "name, id, age, payRate, hoursPerWeek\n\n" +
            "Example: John, 101, 25, 18.50, 40"
        );

        if (!input) return;

        let parts = input.split(",");

        if (parts.length !== 5) {
            alert("Invalid format. Please enter 5 values separated by commas.");
            return;
        }

        let name = parts[0].trim();
        let id = parts[1].trim();
        let age = parseInt(parts[2].trim());
        let payRate = parseFloat(parts[3].trim());
        let hoursPerWeek = parseFloat(parts[4].trim());

        if (isNaN(age) || isNaN(payRate) || isNaN(hoursPerWeek)) {
            alert("Age, pay rate, and hours per week must be numbers.");
            return;
        }

        employees.push(new Employee(name, id, age, payRate, hoursPerWeek));
        alert("Employee added.");
    };

    const removeEmployee = () => {
        let name = prompt("Enter name of employee to remove:");
        let index = employees.findIndex(emp => emp.name === name);

        if (index !== -1) {
            employees.splice(index, 1);
            alert("Employee removed.");
        } else {
            alert("Employee not found.");
        }
    };

    const editEmployee = () => {
        let name = prompt("Enter name of employee to edit:");
        let employee = employees.find(emp => emp.name === name);

        if (!employee) {
            alert("Employee not found.");
            return;
        }

        let newPayRate = prompt("Enter new pay rate for " + employee.name + ":");
        let newHours = prompt("Enter new hours per week for " + employee.name + ":");

        if ((newPayRate !== null && !isNaN(newPayRate)) &&
            (newHours !== null && !isNaN(newHours))) {
            employee.payRate = parseFloat(newPayRate);
            employee.hoursPerWeek = parseFloat(newHours);
            alert("Employee updated.");
        } else {
            alert("Invalid input.");
        }
    };

    const displayEmployee = () => {
        if (employees.length === 0) {
            console.log("No employees to display.");
            return;
        }

        const output = 
            "ID\tName\tAge\tPayRate\tHours\n" +
            "---------------------------------------------\n" +
            employees.map(emp => 
                `${emp.id}\t${emp.name}\t${emp.age}\t${emp.payRate}\t${emp.hoursPerWeek}`
            ).join("\n");

        console.log(output);
        alert("Employee list printed to console.");
    };

    let userChoice;

    while (userChoice !== "5") {
        userChoice = prompt(
            "Main Menu\n\n" +
            "1. Add Employee\n" +
            "2. Remove Employee\n" +
            "3. Edit Employee\n" +
            "4. Display Employee\n" +
            "5. Exit\n\n" +
            "Enter Selection:"
        );

        if (userChoice === "1") {
            addEmployee();
        } 
        else if (userChoice === "2") {
            removeEmployee();
        } 
        else if (userChoice === "3") {
            editEmployee();
        } 
        else if (userChoice === "4") {
            displayEmployee();
        } 
        else if (userChoice === "5") {
            alert("Exiting program.");
        } 
        else {
            alert("Invalid Selection");
        }
    }

})();